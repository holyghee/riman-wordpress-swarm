# Mediation im erweiterten privaten Umfeld

Wenn Konflikte im Umfeld entstehen, hilft ein neutraler Rahmen, wieder Verständnis und Lösungen zu finden.

 ---

 ## Themen im Fokus

 - [Mediation bei Konflikten in der Nachbarschaft und in Vereinen und Gemeinden](nachbarschaft_vereine_gemeinden.md)  
 - [Mediation bei Konflikten im Freundeskreis](freundeskreis.md)  
 - [Mediation bei Konflikten im erweiterten Familienkreis](erweiterter_familienkreis.md)

 ---

 **Brauchen Sie Unterstützung?**  
 Wir moderieren vertraulich – von der Klärung bis zur Vereinbarung.
